-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Mar 10, 2016 at 07:54 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `songlab_test`
--
CREATE DATABASE IF NOT EXISTS `songlab_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `songlab_test`;

-- --------------------------------------------------------

--
-- Table structure for table `collaborations`
--

CREATE TABLE `collaborations` (
  `id` bigint(20) unsigned NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `collaborations`
--

INSERT INTO `collaborations` (`id`, `project_id`, `user_id`) VALUES
(1, 1, 2),
(2, 0, 3),
(3, 0, 4),
(4, 2, 17),
(5, 3, 18),
(6, 4, 18),
(7, 5, 22),
(8, 0, 23),
(9, 0, 24),
(10, 6, 37),
(11, 7, 38),
(12, 8, 38),
(13, 9, 42),
(14, 0, 43),
(15, 0, 44),
(16, 10, 57),
(17, 11, 58),
(18, 12, 58),
(19, 13, 62),
(20, 0, 63),
(21, 0, 64),
(22, 14, 77),
(23, 15, 78),
(24, 16, 78),
(25, 17, 82),
(26, 0, 83),
(27, 0, 84),
(28, 18, 97),
(29, 19, 98),
(30, 20, 98),
(31, 21, 113),
(32, 22, 114),
(33, 23, 114),
(34, 24, 129),
(35, 25, 130),
(36, 26, 130),
(37, 27, 145),
(38, 28, 146),
(39, 29, 146),
(40, 30, 150),
(41, 0, 151),
(42, 0, 152),
(43, 31, 165),
(44, 32, 166),
(45, 33, 166),
(46, 34, 170),
(47, 0, 171),
(48, 0, 172),
(49, 35, 174),
(50, 0, 175),
(51, 0, 176),
(52, 36, 178),
(53, 0, 179),
(54, 0, 180),
(55, 37, 182),
(56, 0, 183),
(57, 0, 184),
(58, 39, 186),
(59, 0, 187),
(60, 0, 188),
(61, 43, 190),
(62, 0, 191),
(63, 0, 192),
(64, 48, 194),
(65, 0, 195),
(66, 0, 196),
(67, 55, 198),
(68, 0, 199),
(69, 0, 200),
(70, 62, 202),
(71, 63, 203),
(72, 63, 204);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) unsigned NOT NULL,
  `message` text,
  `sender` varchar(255) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messages_user`
--

CREATE TABLE `messages_user` (
  `id` bigint(20) unsigned NOT NULL,
  `message_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages_user`
--

INSERT INTO `messages_user` (`id`, `message_id`, `user_id`) VALUES
(1, 79, 79),
(2, 99, 99),
(3, 100, 100),
(4, 3, 100),
(5, 115, 115),
(6, 116, 116),
(7, 6, 116),
(8, 6, 131),
(9, 132, 132),
(10, 9, 132),
(11, 7, 147),
(12, 8, 148),
(13, 9, 148),
(14, 13, 167),
(15, 14, 168),
(16, 15, 168);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) unsigned NOT NULL,
  `title` varchar(225) NOT NULL,
  `description` varchar(225) NOT NULL,
  `genre` varchar(225) NOT NULL,
  `resources` varchar(8000) NOT NULL,
  `lyrics` text NOT NULL,
  `type` varchar(225) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL,
  `first_name` varchar(225) NOT NULL,
  `last_name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `bio` mediumtext NOT NULL,
  `photo` varchar(700) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `collaborations`
--
ALTER TABLE `collaborations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `messages_user`
--
ALTER TABLE `messages_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `collaborations`
--
ALTER TABLE `collaborations`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=73;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `messages_user`
--
ALTER TABLE `messages_user`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=205;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
